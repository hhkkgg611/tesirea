#!/bin/bash
set -euo pipefail
RECOVERY_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RECOVERY_ROOT"
python3 rebuild/patch.py
rm -rf rebuild/classes rebuild/dex rebuild/test-classes
mkdir -p rebuild/classes rebuild/dex rebuild/test-classes output
java rebuild/Compile.java -source 8 -target 8 -Xlint:-options -classpath tools/json.jar -d rebuild/test-classes rebuild/src/com/vibecast/recovery/SearchText.java rebuild/src/com/vibecast/recovery/RecordOptions.java rebuild/tests/SearchTextTest.java rebuild/tests/RecordOptionsTest.java
java -cp rebuild/test-classes:tools/json.jar SearchTextTest
java -cp rebuild/test-classes:tools/json.jar RecordOptionsTest
java rebuild/Compile.java -source 8 -target 8 -Xlint:-options -classpath tools/android-sdk/android-36/android.jar -d rebuild/classes rebuild/src/com/vibecast/recovery/SearchText.java rebuild/src/com/vibecast/recovery/RecordOptions.java rebuild/src/com/vibecast/recovery/RecoverySearch.java
python3 - <<'PY'
from pathlib import Path
import subprocess
r=Path.cwd()
subprocess.run([str(r/'tools/android-sdk/android-16/d8'),'--min-api','24','--lib',str(r/'tools/android-sdk/android-36/android.jar'),'--output',str(r/'rebuild/dex')]+[str(p) for p in (r/'rebuild/classes').rglob('*.class')],check=True)
PY
cp rebuild/dex/classes.dex merged/classes12.dex
java -jar tools/apktool.jar b -p tools/apktool-framework merged -o rebuild/lplayer-test-unsigned.apk
# Sign the generated candidate with the clearly identified public Android debug certificate.
SIGN_WORK_DIR="$(mktemp -d "$RECOVERY_ROOT/rebuild/sign.XXXXXX")"
java -jar tools/uber-apk-signer.jar --apks rebuild/lplayer-test-unsigned.apk --out "$SIGN_WORK_DIR" --zipAlignPath "$RECOVERY_ROOT/tools/android-sdk/android-16/zipalign" --allowResign
test -s "$SIGN_WORK_DIR/lplayer-test-aligned-debugSigned.apk"
cp "$SIGN_WORK_DIR/lplayer-test-aligned-debugSigned.apk" output/Lplayer-1.9.6-Recovery-Test-2.apk
tools/android-sdk/android-16/apksigner verify --verbose output/Lplayer-1.9.6-Recovery-Test-2.apk
tools/android-sdk/android-16/zipalign -c 4 output/Lplayer-1.9.6-Recovery-Test-2.apk
sha256sum output/Lplayer-1.9.6-Recovery-Test-2.apk > output/SHA256SUMS.txt
