import com.vibecast.recovery.RecordOptions;
import java.util.List;

public class RecordOptionsTest {
    static int passed;
    static void check(boolean value, String label) { if (!value) throw new AssertionError(label); passed++; }
    static class Item implements RecordOptions.Item {
        final long date; final String title, key;
        Item(long date, String title, String key) { this.date = date; this.title = title; this.key = key; }
        public long date() { return date; }
        public String title() { return title; }
        public String key() { return key; }
    }
    public static void main(String[] args) {
        long now = 1793361600000L, day = RecordOptions.DAY;
        check(RecordOptions.timestamp("1793361600") == now, "Unix seconds");
        check(RecordOptions.timestamp("1793361600000") == now, "Unix milliseconds");
        check(RecordOptions.timestamp("1793361600.125") == now + 125, "fractional seconds");
        for (String invalid : new String[]{null, "", "bad", "NaN", "Infinity", "-1", "0", "999999999999999999"})
            check(RecordOptions.timestamp(invalid) == 0, "unknown/invalid timestamp: " + invalid);
        check(RecordOptions.dateMatches(0, 0, now, 0, 0), "all dates includes unknown");
        check(RecordOptions.dateMatches(0, 5, now, 0, 0), "unknown date filter");
        check(!RecordOptions.dateMatches(now, 5, now, 0, 0), "known dates excluded by unknown filter");
        check(!RecordOptions.dateMatches(0, 1, now, 0, 0), "unknown dates excluded by recent filter");
        check(RecordOptions.dateMatches(now - 7 * day, 1, now, 0, 0), "seven-day boundary inclusive");
        check(!RecordOptions.dateMatches(now - 7 * day - 1, 1, now, 0, 0), "older than seven days");
        check(!RecordOptions.dateMatches(now + 1, 1, now, 0, 0), "future dates excluded from recent filter");
        check(RecordOptions.dateMatches(now - 30 * day, 2, now, 0, 0), "30-day boundary");
        check(RecordOptions.dateMatches(now - 365 * day, 3, now, 0, 0), "365-day boundary");
        check(!RecordOptions.dateMatches(now - 366 * day, 3, now, 0, 0), "older than 365 days");
        check(RecordOptions.dateMatches(now, 4, now, now, now + day), "custom range start included");
        check(RecordOptions.dateMatches(now + day - 1, 4, now, now, now + day), "entire final day included");
        check(!RecordOptions.dateMatches(now + day, 4, now, now, now + day), "next day excluded");
        check(!RecordOptions.dateMatches(0, 4, now, now, now + day), "custom range excludes unknown dates");
        for (int sort = 0; sort < 2; sort++) {
            RecordOptions.Top<Item> top = new RecordOptions.Top<Item>(4, sort);
            top.add(new Item(0, "Unknown", "z")); top.add(new Item(now, "New", "b")); top.add(new Item(now - day, "Old", "a"));
            List<Item> items = top.sorted();
            check(items.get(2).date == 0, "unknown dates last in both directions");
            check(items.get(0).date == (sort == 0 ? now : now - day), "newest/oldest order");
        }
        RecordOptions.Top<Item> top = new RecordOptions.Top<Item>(200, 0);
        for (int i = 0; i < 1000; i++) top.add(new Item(now + i, "Item", String.valueOf(i)));
        check(top.matches == 1000 && top.sorted().size() == 200, "accurate count with bounded output");
        check(top.sorted().get(0).date == now + 999 && top.sorted().get(199).date == now + 800, "late matches compete before truncation");
        for (int sort = 2; sort < 4; sort++) {
            top = new RecordOptions.Top<Item>(4, sort);
            top.add(new Item(now, "Zoo", "z")); top.add(new Item(0, "Café", "c")); top.add(new Item(now, "apple", "a"));
            check(top.sorted().get(0).key.equals(sort == 2 ? "a" : "z"), "alphabetical ascending/descending");
        }
        top = new RecordOptions.Top<Item>(2, 0);
        top.add(new Item(now, "Equal", "b")); top.add(new Item(now, "Equal", "a"));
        check(top.sorted().get(0).key.equals("a"), "deterministic date ties");
        System.out.println(passed + " date/filter/sorting checks passed");
    }
}
