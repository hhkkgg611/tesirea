package com.vibecast.recovery;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TreeSet;
import java.text.DateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Native search surface added to the recovered Flutter launcher. No remote service is invented. */
public final class RecoverySearch {
    private static final int FG = Color.rgb(232, 236, 244);
    private static final int BG = Color.rgb(18, 23, 34);
    private static final int PANEL = Color.rgb(31, 39, 55);

    public static void install(final Activity activity) {
        Button open = new Button(activity);
        open.setText("Search");
        open.setTextColor(Color.WHITE);
        open.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(58, 91, 180)));
        open.setContentDescription("Search saved accounts, channels and videos");
        FrameLayout.LayoutParams layout = new FrameLayout.LayoutParams(dp(activity, 96), dp(activity, 46), Gravity.TOP | Gravity.END);
        layout.setMargins(dp(activity, 8), dp(activity, 52), dp(activity, 12), 0);
        activity.addContentView(open, layout);
        open.setOnClickListener(v -> new Screen(activity).show());
    }

    private static int dp(Activity a, int n) { return (int)(n * a.getResources().getDisplayMetrics().density + .5f); }
    private static TextView text(Activity a, String content, int size) {
        TextView view = new TextView(a); view.setText(content); view.setTextColor(FG); view.setTextSize(size); return view;
    }

    private static final class Row implements RecordOptions.Item {
        final String id, category;
        final SearchText.Text text;
        final long recorded;
        Row(String id, String category, SearchText.Text text, long recorded) { this.id = id; this.category = category; this.text = text; this.recorded = recorded; }
        public long date() { return recorded; }
        public String title() { return text.title(); }
        public String key() { return id; }
    }

    private static final class Scan {
        final List<Row> rows = new ArrayList<Row>();
        int examined, unreadable, errors, limited, matches;
    }

    private static final class Screen {
        final Activity activity;
        final Dialog dialog;
        final Handler ui = new Handler(Looper.getMainLooper());
        final ExecutorService worker = Executors.newSingleThreadExecutor();
        Future<?> current;
        Runnable pending;
        int generation;
        boolean closed;
        TextView status;
        EditText query;
        Spinner filter, sort, dateFilter;
        CheckBox videoOnly;
        long fromDay = midnight(-6), untilDay = midnight(1);
        LinearLayout results;
        final String[] categories = {"All saved content", "Accounts & channels", "Library", "History", "Downloads"};

        Screen(Activity activity) { this.activity = activity; dialog = new Dialog(activity); }

        void show() {
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            LinearLayout root = new LinearLayout(activity); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(activity, 18), dp(activity, 18), dp(activity, 18), dp(activity, 12));
            LinearLayout bar = new LinearLayout(activity); bar.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = text(activity, "Search saved content", 22); title.setTypeface(null, Typeface.BOLD);
            bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
            Button close = new Button(activity); close.setText("Close"); close.setOnClickListener(v -> dialog.dismiss()); bar.addView(close); root.addView(bar);
            TextView scope = text(activity, "Searches records saved on this device. Dates refer to when records were saved, not video publication. Online catalog search is not connected.", 14); scope.setPadding(0, dp(activity, 8), 0, dp(activity, 12)); root.addView(scope);
            query = new EditText(activity); query.setSingleLine(true); query.setTextColor(FG); query.setHintTextColor(Color.LTGRAY); query.setHint("Channel, account or video name"); query.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(120, 160, 240))); root.addView(query, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout options = new LinearLayout(activity);
            filter = spinner(categories); filter.setContentDescription("Filter saved content by category");
            sort = spinner(new String[]{"Saved date: newest first", "Saved date: oldest first", "Title: A–Z", "Title: Z–A"}); sort.setContentDescription("Sort saved records");
            options.addView(filter, new LinearLayout.LayoutParams(0, -2, 1)); options.addView(sort, new LinearLayout.LayoutParams(0, -2, 1)); root.addView(options);
            LinearLayout dates = new LinearLayout(activity);
            dateFilter = spinner(new String[]{"Any saved date", "Saved in last 7 days", "Saved in last 30 days", "Saved in last 365 days", "Custom saved-date range", "Unknown saved date"});
            dates.addView(dateFilter, new LinearLayout.LayoutParams(0, -2, 1));
            Button range = new Button(activity); range.setText("Dates…"); range.setOnClickListener(v -> chooseDates()); dates.addView(range); root.addView(dates);
            videoOnly = new CheckBox(activity); videoOnly.setText("Only records with video links"); videoOnly.setTextColor(FG); root.addView(videoOnly);
            status = text(activity, "Reading saved records…", 13); status.setPadding(0, dp(activity, 8), 0, dp(activity, 8)); root.addView(status);
            results = new LinearLayout(activity); results.setOrientation(LinearLayout.VERTICAL); root.addView(results, new LinearLayout.LayoutParams(-1, -2));
            ScrollView page = new ScrollView(activity); page.setFillViewport(true); page.addView(root);
            dialog.setContentView(page); dialog.setOnDismissListener(d -> { closed = true; generation++; if (pending != null) ui.removeCallbacks(pending); if (current != null) current.cancel(true); worker.shutdownNow(); });
            dialog.show(); dialog.getWindow().setLayout(-1, -1);
            query.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s, int start, int count, int after) {} public void onTextChanged(CharSequence s, int start, int before, int count) { schedule(); } public void afterTextChanged(Editable e) {} });
            android.widget.AdapterView.OnItemSelectedListener listener = new android.widget.AdapterView.OnItemSelectedListener() { public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { schedule(); } public void onNothingSelected(android.widget.AdapterView<?> parent) {} };
            filter.setOnItemSelectedListener(listener); sort.setOnItemSelectedListener(listener); dateFilter.setOnItemSelectedListener(listener);
            videoOnly.setOnCheckedChangeListener((button, checked) -> schedule());
            schedule();
        }

        Spinner spinner(String[] items) {
            Spinner view = new Spinner(activity);
            ArrayAdapter<String> choices = new ArrayAdapter<String>(activity, android.R.layout.simple_spinner_item, items) {
                public View getView(int p, View v, ViewGroup parent) { TextView t = (TextView)super.getView(p, v, parent); t.setTextColor(FG); t.setSingleLine(false); t.setTextSize(13); t.setPadding(0, dp(activity, 10), dp(activity, 4), dp(activity, 10)); return t; }
            };
            choices.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); view.setAdapter(choices); return view;
        }

        static long midnight(int offset) {
            Calendar day = Calendar.getInstance(); day.set(Calendar.HOUR_OF_DAY, 0); day.set(Calendar.MINUTE, 0); day.set(Calendar.SECOND, 0); day.set(Calendar.MILLISECOND, 0); day.add(Calendar.DATE, offset); return day.getTimeInMillis();
        }

        void chooseDates() {
            final Calendar start = Calendar.getInstance(), end = Calendar.getInstance(); start.setTimeInMillis(fromDay); end.setTimeInMillis(untilDay); end.add(Calendar.DATE, -1);
            LinearLayout form = new LinearLayout(activity); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(dp(activity, 20), 0, dp(activity, 20), 0);
            Button first = new Button(activity), last = new Button(activity); form.addView(first); form.addView(last);
            Runnable labels = () -> { first.setText("From: " + DateFormat.getDateInstance().format(start.getTime())); last.setText("Through: " + DateFormat.getDateInstance().format(end.getTime())); }; labels.run();
            first.setOnClickListener(v -> pickDay(start, labels)); last.setOnClickListener(v -> pickDay(end, labels));
            AlertDialog picker = new AlertDialog.Builder(activity).setTitle("Saved-date range").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Apply", null).create();
            picker.show(); picker.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                if (start.after(end)) { Toast.makeText(activity, "The start date must be on or before the end date.", Toast.LENGTH_LONG).show(); return; }
                fromDay = start.getTimeInMillis(); end.add(Calendar.DATE, 1); untilDay = end.getTimeInMillis(); dateFilter.setSelection(4); schedule(); picker.dismiss();
            });
        }

        void pickDay(Calendar day, Runnable changed) {
            new android.app.DatePickerDialog(activity, (view, year, month, date) -> { day.set(year, month, date, 0, 0, 0); day.set(Calendar.MILLISECOND, 0); changed.run(); }, day.get(Calendar.YEAR), day.get(Calendar.MONTH), day.get(Calendar.DAY_OF_MONTH)).show();
        }

        void schedule() {
            if (closed) return;
            final int request = ++generation;
            if (pending != null) ui.removeCallbacks(pending);
            if (current != null) current.cancel(true);
            pending = () -> {
                final String needle = query.getText().toString();
                final int selected = filter.getSelectedItemPosition(), ordering = sort.getSelectedItemPosition(), dates = dateFilter.getSelectedItemPosition();
                final boolean mediaOnly = videoOnly.isChecked();
                final long from = fromDay, until = untilDay, now = System.currentTimeMillis();
                status.setText("Searching saved records…");
                current = worker.submit(() -> {
                    final Scan scan = readRecords(activity, needle, selected, categories, ordering, dates, mediaOnly, from, until, now);
                    ui.post(() -> { if (!closed && request == generation) render(scan); });
                });
            };
            ui.postDelayed(pending, 250);
        }

        void render(Scan scan) {
            results.removeAllViews();
            String note = "Showing " + scan.rows.size() + " of " + scan.matches + " matches · " + scan.examined + " saved records checked";
            if (dateFilter.getSelectedItemPosition() == 4) note += "\nSaved " + DateFormat.getDateInstance().format(new Date(fromDay)) + " through " + DateFormat.getDateInstance().format(new Date(untilDay - 1));
            if (scan.limited > 0) note += " · scan or field coverage limited";
            if (scan.unreadable > 0) note += " · " + scan.unreadable + " unreadable records";
            if (scan.errors > 0) note += " · " + scan.errors + " database read errors";
            status.setText(note);
            if (scan.rows.isEmpty()) {
                results.addView(text(activity, scan.examined == 0 ? "No saved records found. Browse the app, save videos or add accounts, then open Search again. This test installation has its own storage." : "No matching saved records. Try fewer words or reset the filters.", 16));
                return;
            }
            for (final Row row : scan.rows) {
                LinearLayout card = new LinearLayout(activity); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(activity, 14), dp(activity, 12), dp(activity, 14), dp(activity, 12)); card.setBackgroundColor(PANEL);
                TextView name = text(activity, row.text.title(), 17); name.setTypeface(null, Typeface.BOLD); card.addView(name);
                TextView source = text(activity, row.category + " · " + (row.recorded == 0 ? "Saved date unknown" : "Saved " + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(row.recorded))), 12); source.setTextColor(Color.rgb(150, 183, 255)); card.addView(source);
                TextView detail = text(activity, row.text.description(), 13); detail.setMaxLines(3); detail.setPadding(0, dp(activity, 6), 0, 0); card.addView(detail);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(activity, 8); results.addView(card, lp);
                card.setOnClickListener(v -> showRecord(row));
            }
        }

        void showRecord(Row row) {
            TextView detail = new TextView(activity); detail.setText(row.text.description()); detail.setTextIsSelectable(true); detail.setPadding(dp(activity, 20), dp(activity, 12), dp(activity, 20), dp(activity, 12));
            ScrollView scroll = new ScrollView(activity); scroll.addView(detail);
            AlertDialog.Builder builder = new AlertDialog.Builder(activity).setTitle(row.text.title()).setView(scroll).setNegativeButton("Close", null);
            final String media = playable(row.text.media);
            if (media != null) builder.setPositiveButton("Play video", (d, which) -> play(media));
            builder.show();
        }

        String playable(List<String> candidates) {
            for (String value : candidates) {
                Uri uri = Uri.parse(value);
                if ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme())) return value;
                if (uri.getScheme() == null || "file".equals(uri.getScheme())) {
                    try {
                        File file = new File(uri.getScheme() == null ? value : uri.getPath()).getCanonicalFile();
                        File data = new File(activity.getApplicationInfo().dataDir).getCanonicalFile();
                        File external = activity.getExternalFilesDir(null);
                        if (file.isFile() && (file.getPath().startsWith(data.getPath() + "/") || (external != null && file.getPath().startsWith(external.getCanonicalPath() + "/")))) return Uri.fromFile(file).toString();
                    } catch (Exception ignored) {}
                }
            }
            return null;
        }

        void play(String uri) {
            Dialog player = new Dialog(activity); player.requestWindowFeature(Window.FEATURE_NO_TITLE);
            LinearLayout root = new LinearLayout(activity); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.BLACK);
            Button close = new Button(activity); close.setText("Close video"); root.addView(close);
            VideoView video = new VideoView(activity); root.addView(video, new LinearLayout.LayoutParams(-1, 0, 1));
            MediaController controls = new MediaController(activity); controls.setAnchorView(video); video.setMediaController(controls);
            close.setOnClickListener(v -> player.dismiss()); player.setOnDismissListener(d -> video.stopPlayback());
            video.setOnErrorListener((mp, what, extra) -> { Toast.makeText(activity, "This saved media could not be played. Its link may have expired or require the original player.", Toast.LENGTH_LONG).show(); player.dismiss(); return true; });
            player.setContentView(root); player.show(); player.getWindow().setLayout(-1, -1); video.setVideoURI(Uri.parse(uri)); video.start();
        }
    }

    private static Scan readRecords(Activity activity, String query, int selected, String[] categories, int sort, int dates, boolean mediaOnly, long from, long until, long now) {
        Scan out = new Scan();
        RecordOptions.Top<Row> top = new RecordOptions.Top<Row>(200, sort);
        Set<String> paths = new TreeSet<String>();
        for (String name : new String[]{"view_hub.db", "download.db"}) {
            File file = activity.getDatabasePath(name);
            if (file.isFile()) paths.add(file.getAbsolutePath());
        }
        for (String folder : new String[]{"app_flutter", "files", "databases"}) discover(new File(activity.getApplicationInfo().dataDir, folder), paths, 0);
        scanFiles: for (String path : paths) {
            if (Thread.currentThread().isInterrupted()) return out;
            try (SQLiteDatabase db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS)) {
                String[][] tables = {{"link_user_table", "Accounts & channels"}, {"table_library", "Library"}, {"table_history", "History"}, {"download_tasks", "Downloads"}};
                Set<String> existing = new HashSet<String>();
                try (Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null)) { while (cursor.moveToNext()) existing.add(cursor.getString(0)); }
                for (String[] table : tables) {
                    if (!existing.contains(table[0]) || (selected > 0 && !categories[selected].equals(table[1]))) continue;
                    String key = table[0].equals("download_tasks") ? "task_id" : "id";
                    String timestamp = table[0].equals("download_tasks") ? "created_at" : "create_timestamp";
                    Set<String> columns = new HashSet<String>();
                    try (Cursor cursor = db.rawQuery("PRAGMA table_info(" + table[0] + ")", null)) { while (cursor.moveToNext()) columns.add(cursor.getString(1)); }
                    if (!columns.contains(timestamp)) timestamp = "NULL";
                    try (Cursor cursor = db.rawQuery("SELECT " + key + ", content, " + timestamp + " FROM " + table[0] + " ORDER BY " + key, null)) {
                        while (cursor.moveToNext()) {
                            if (Thread.currentThread().isInterrupted()) return out;
                            if (out.examined >= 50000) { out.limited++; break scanFiles; }
                            out.examined++;
                            try {
                                long recorded = RecordOptions.timestamp(cursor.isNull(2) ? null : cursor.getString(2));
                                if (!RecordOptions.dateMatches(recorded, dates, now, from, until)) continue;
                                String content = cursor.getString(1);
                                if (content == null || content.length() > 1048576) { out.unreadable++; continue; }
                                SearchText.Text text = SearchText.parse(content);
                                if (text.incomplete) out.limited++;
                                if ((!mediaOnly || !text.media.isEmpty()) && text.matches(query)) top.add(new Row(path + "/" + table[0] + "/" + cursor.getString(0), table[1], text, recorded));
                            } catch (Exception error) { out.unreadable++; }
                        }
                    } catch (Exception error) { out.errors++; }
                }
            } catch (Exception error) { out.errors++; }
        }
        out.rows.addAll(top.sorted()); out.matches = top.matches;
        return out;
    }

    private static void discover(File dir, Set<String> paths, int depth) {
        if (depth > 3 || Thread.currentThread().isInterrupted()) return;
        File[] files = dir.listFiles(); if (files == null) return;
        for (File file : files) {
            if (file.isDirectory()) discover(file, paths, depth + 1);
            else if (file.getName().equals("view_hub.db") || file.getName().equals("download.db")) paths.add(file.getAbsolutePath());
        }
    }
}
