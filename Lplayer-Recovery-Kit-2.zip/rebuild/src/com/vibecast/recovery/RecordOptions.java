package com.vibecast.recovery;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/** Date filtering and bounded sorting, independent of Android/database code. */
public final class RecordOptions {
    public interface Item {
        long date();
        String title();
        String key();
    }
    public static final long DAY = 86400000L;
    // Recovered tables use Unix seconds or milliseconds. Zero/invalid values mean unknown.
    public static long timestamp(String raw) {
        if (raw == null) return 0;
        try {
            double value = Double.parseDouble(raw);
            if (Double.isNaN(value) || Double.isInfinite(value) || value <= 0) return 0;
            double millis = value < 100000000000L ? value * 1000 : value;
            return millis <= 4102444800000L ? (long)millis : 0;
        } catch (NumberFormatException e) { return 0; }
    }
    public static boolean dateMatches(long date, int filter, long now, long from, long until) {
        if (filter == 0) return true;
        if (filter == 5) return date == 0;
        if (date == 0) return false;
        if (filter == 4) return date >= from && date < until;
        long days = filter == 1 ? 7 : filter == 2 ? 30 : 365;
        return date >= now - days * DAY && date <= now;
    }
    public static <T extends Item> Comparator<T> comparator(final int sort) {
        return (a, b) -> {
            int order;
            if (sort < 2) {
                if (a.date() == 0 && b.date() != 0) return 1;
                if (b.date() == 0 && a.date() != 0) return -1;
                order = sort == 0 ? Long.compare(b.date(), a.date()) : Long.compare(a.date(), b.date());
            } else {
                order = SearchText.normalize(a.title()).compareTo(SearchText.normalize(b.title()));
                if (sort == 3) order = -order;
            }
            return order != 0 ? order : a.key().compareTo(b.key());
        };
    }
    /** Retain the best N after scanning; never truncate before applying the ordering. */
    public static final class Top<T extends Item> {
        private final int limit;
        private final Comparator<T> order;
        private final PriorityQueue<T> heap;
        public int matches;
        public Top(int limit, int sort) {
            this.limit = limit; order = RecordOptions.<T>comparator(sort);
            heap = new PriorityQueue<T>(limit, Collections.reverseOrder(order));
        }
        public void add(T item) {
            matches++;
            if (heap.size() < limit) heap.add(item);
            else if (order.compare(item, heap.peek()) < 0) { heap.poll(); heap.add(item); }
        }
        public List<T> sorted() { List<T> out = new ArrayList<T>(heap); Collections.sort(out, order); return out; }
    }
}
