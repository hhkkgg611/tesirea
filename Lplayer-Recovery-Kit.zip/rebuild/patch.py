"""Reproducible, test-only binary adaptation. Original extracted inputs are retained."""
from pathlib import Path
import re
import shutil
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / 'merged'
SOURCE = ROOT / 'decoded'
patched = []

for number in (4, 7, 9):
    target = WORK / f'smali_classes{number}'
    shutil.copytree(SOURCE / target.name, target, dirs_exist_ok=True)
    (WORK / f'classes{number}.dex').unlink(missing_ok=True)

def method(path, signature, body):
    text = path.read_text()
    pattern = r'^\.method ' + re.escape(signature) + r'\n.*?^\.end method'
    text, count = re.subn(pattern, '.method ' + signature + '\n' + body.strip() + '\n.end method', text, flags=re.M | re.S)
    if count != 1:
        raise RuntimeError(f'{path.name}: expected one method {signature}, got {count}')
    path.write_text(text)
    patched.append(f'{path.relative_to(WORK)} :: {signature}')

G = 'Lio/flutter/plugins/googlemobileads/'
google = WORK / 'smali_classes4/io/flutter/plugins/googlemobileads'
for name in ['FlutterBannerAd', 'FlutterNativeAd', 'FlutterRewardedAd', 'FlutterAppOpenAd', 'FlutterInterstitialAd', 'FlutterAdManagerBannerAd', 'FlutterAdManagerInterstitialAd', 'FlutterRewardedInterstitialAd']:
    method(google / (name + '.smali'), 'load()V', f'''
    .locals 7
    new-instance v0, {G}FlutterAd$FlutterLoadAdError;
    const/4 v1, 0x3
    const-string v2, "recovery.test"
    const-string v3, "Ads disabled in recovery test build"
    const/4 v4, 0x0
    invoke-direct {{v0, v1, v2, v3, v4}}, {G}FlutterAd$FlutterLoadAdError;-><init>(ILjava/lang/String;Ljava/lang/String;{G}FlutterAd$FlutterResponseInfo;)V
    iget-object v5, p0, {G}{name};->manager:{G}AdInstanceManager;
    iget v6, p0, {G}FlutterAd;->adId:I
    invoke-virtual {{v5, v6, v0}}, {G}AdInstanceManager;->onAdFailedToLoad(I{G}FlutterAd$FlutterLoadAdError;)V
    return-void
    ''')

M = 'Lcom/applovin/applovin_max/AppLovinMAX;'
E = 'Lcom/applovin/impl/mediation/MaxErrorImpl;'
maxdir = WORK / 'smali_classes7/com/applovin/applovin_max'
maxfile = maxdir / 'AppLovinMAX.smali'
helper = f'''
.method private recoveryLoadFailed(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    new-instance v0, {E}
    const/16 v1, 0xcc
    const-string v2, "Ads disabled in recovery test build"
    invoke-direct {{v0, v1, v2}}, {E}-><init>(ILjava/lang/String;)V
    invoke-virtual {{p0, p1, v0}}, {M}->getAdLoadFailedInfo(Ljava/lang/String;Lcom/applovin/mediation/MaxError;)Ljava/util/Map;
    move-result-object v0
    invoke-virtual {{p0, p2, v0}}, {M}->fireCallback(Ljava/lang/String;Ljava/util/Map;)V
    return-void
.end method
'''
maxfile.write_text(maxfile.read_text() + helper)
for name, event in [('loadInterstitial', 'OnInterstitialLoadFailedEvent'), ('loadRewardedAd', 'OnRewardedAdLoadFailedEvent'), ('loadAppOpenAd', 'OnAppOpenAdLoadFailedEvent')]:
    method(maxfile, f'public {name}(Ljava/lang/String;)V', f'''
    .locals 1
    const-string v0, "{event}"
    invoke-direct {{p0, p1, v0}}, {M}->recoveryLoadFailed(Ljava/lang/String;Ljava/lang/String;)V
    return-void
    ''')

for signature in ['private loadAdView(Ljava/lang/String;Lcom/applovin/mediation/MaxAdFormat;)V', 'private createAdView(Ljava/lang/String;Lcom/applovin/mediation/MaxAdFormat;Ljava/lang/String;Z)V']:
    method(maxfile, signature, f'''
    .locals 1
    sget-object v0, Lcom/applovin/mediation/MaxAdFormat;->MREC:Lcom/applovin/mediation/MaxAdFormat;
    if-ne p2, v0, :banner
    const-string v0, "OnMRecAdLoadFailedEvent"
    goto :emit
    :banner
    const-string v0, "OnBannerAdLoadFailedEvent"
    :emit
    invoke-direct {{p0, p1, v0}}, {M}->recoveryLoadFailed(Ljava/lang/String;Ljava/lang/String;)V
    return-void
    ''')

for name in ['isInterstitialReady', 'isRewardedAdReady', 'isAppOpenAdReady']:
    method(maxfile, f'public {name}(Ljava/lang/String;Lio/flutter/plugin/common/MethodChannel$Result;)V', '''
    .locals 1
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    invoke-interface {p2, v0}, Lio/flutter/plugin/common/MethodChannel$Result;->success(Ljava/lang/Object;)V
    return-void
    ''')

for name, event in [('showInterstitial', 'OnInterstitialAdFailedToDisplayEvent'), ('showRewardedAd', 'OnRewardedAdFailedToDisplayEvent'), ('showAppOpenAd', 'OnAppOpenAdFailedToDisplayEvent')]:
    method(maxfile, f'public {name}(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V', f'''
    .locals 1
    const-string v0, "{event}"
    invoke-direct {{p0, p1, v0}}, {M}->recoveryLoadFailed(Ljava/lang/String;Ljava/lang/String;)V
    return-void
    ''')

for name in ['showAdView', 'startAdViewAutoRefresh']:
    method(maxfile, f'private {name}(Ljava/lang/String;Lcom/applovin/mediation/MaxAdFormat;)V', '.locals 0\n    return-void')

W = 'Lcom/applovin/applovin_max/AppLovinMAXAdViewWidget;'
method(maxdir / 'AppLovinMAXAdViewWidget.smali', 'public loadAd()V', f'''
    .locals 4
    new-instance v0, {E}
    const/16 v1, 0xcc
    const-string v2, "Ads disabled in recovery test build"
    invoke-direct {{v0, v1, v2}}, {E}-><init>(ILjava/lang/String;)V
    invoke-virtual {{p0}}, {W}->getAdUnitId()Ljava/lang/String;
    move-result-object v3
    invoke-virtual {{p0, v3, v0}}, {W}->onAdLoadFailed(Ljava/lang/String;Lcom/applovin/mediation/MaxError;)V
    return-void
''')
method(maxdir / 'AppLovinMAXAdViewWidget.smali', 'public setAutoRefreshEnabled(Z)V', '.locals 0\n    return-void')
N = 'Lcom/applovin/applovin_max/AppLovinMAXNativeAdView'
method(maxdir / 'AppLovinMAXNativeAdView.smali', 'private loadAd()V', f'''
    .locals 5
    new-instance v0, {E}
    const/16 v1, 0xcc
    const-string v2, "Ads disabled in recovery test build"
    invoke-direct {{v0, v1, v2}}, {E}-><init>(ILjava/lang/String;)V
    new-instance v3, {N}$NativeAdListener;
    const/4 v4, 0x0
    invoke-direct {{v3, p0, v4}}, {N}$NativeAdListener;-><init>({N};{N}$1;)V
    iget-object v4, p0, {N};->adUnitId:Ljava/lang/String;
    invoke-virtual {{v3, v4, v0}}, {N}$NativeAdListener;->onNativeAdLoadFailed(Ljava/lang/String;Lcom/applovin/mediation/MaxError;)V
    return-void
''')

activity = WORK / 'smali_classes9/com/vibecast/vistata/MainActivity.smali'
activity.write_text(activity.read_text() + '''
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0
    invoke-super {p0, p1}, Lio/flutter/embedding/android/FlutterActivity;->onCreate(Landroid/os/Bundle;)V
    invoke-static {p0}, Lcom/vibecast/recovery/RecoverySearch;->install(Landroid/app/Activity;)V
    return-void
.end method
''')

# A separate, test-signed install preserves the user's existing app and storage.
android = '{http://schemas.android.com/apk/res/android}'
ET.register_namespace('android', android[1:-1])
manifest = WORK / 'AndroidManifest.xml'
tree = ET.parse(manifest)
root = tree.getroot()
old = 'com.vibecast.vistata'
new = old + '.recoverytest'
root.set('package', new)
app = root.find('application')
app.set(android + 'label', 'Lplayer Recovery Test')
# The recovered Play-distribution Application checks the original store signature.
# The testing build uses the standard Application; no billing entitlements are changed.
app.set(android + 'name', 'android.app.Application')
for element in root.iter():
    authority = element.get(android + 'authorities')
    if authority and authority.startswith(old + '.'):
        suffix = authority[len(old):]
        while suffix.startswith('.recoverytest'):
            suffix = suffix[len('.recoverytest'):]
        element.set(android + 'authorities', new + suffix)
    name = element.get(android + 'name')
    if name == old + '.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION':
        element.set(android + 'name', new + '.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION')
tree.write(manifest, encoding='utf-8', xml_declaration=True)
yml = WORK / 'apktool.yml'
text = yml.read_text().replace('versionName: 1.9.6\n', 'versionName: 1.9.6-recovery-test\n')
text = re.sub(r'  renameManifestPackage: .*', '  renameManifestPackage: ' + new, text)
yml.write_text(text)
(ROOT / 'rebuild/patch-manifest.txt').write_text('\n'.join(patched) + '\n')
print(f'Patched {len(patched)} advertising methods and added native search launcher. Test package: {new}')
