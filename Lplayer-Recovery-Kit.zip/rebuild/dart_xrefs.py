from pathlib import Path
import re,json
from capstone import Cs,CS_ARCH_ARM64,CS_MODE_ARM
from elftools.elf.elffile import ELFFile

root=Path(__file__).resolve().parent.parent
pool={}
for line in (root/'dart-analysis/pp.txt').read_text().splitlines():
    m=re.match(r'\[pp\+(0x[0-9a-f]+)\] (.*)',line)
    if m:pool[int(m[1],16)]=m[2]
with open(root/'native/lib/arm64-v8a/libapp.so','rb') as f:
    elf=ELFFile(f);section=elf.get_section_by_name('.text');code=section.data();base=section['sh_addr']
decoder=Cs(CS_ARCH_ARM64,CS_MODE_ARM)
decoder.skipdata=True
last=None;refs=[];start=base
with open(root/'dart-native.asm','w') as output:
    for addr,size,op,args in decoder.disasm_lite(code,base):
        if op=='stp' and args.startswith('x29, x30, [x15, #-0x10]!'):start=addr
        off=None
        m=re.match(r'x\d+, \[x27, #(0x[0-9a-f]+)\]',args)
        if op=='ldr' and m:off=int(m[1],16)
        if last and last[0]+4==addr and op=='ldr':
            m=re.match(r'x\d+, \['+last[1]+r', #(0x[0-9a-f]+)\]',args)
            if m:off=last[2]+int(m[1],16)
        last=None
        m=re.match(r'(x\d+), x27, #(0x[0-9a-f]+)(?:, lsl #12)?$',args)
        if op=='add' and m:last=(addr,m[1],int(m[2],16)*(4096 if 'lsl #12' in args else 1))
        comment=''
        if off in pool:
            comment=' ; '+pool[off]
            refs.append({'address':addr,'function_start':start,'pool_offset':off,'value':pool[off]})
        output.write(f'{addr:08x} {op:8} {args}{comment}\n')
(root/'dart-xrefs.json').write_text(json.dumps(refs))
for ref in refs:
    if '/v1/' in ref['value'] or 'vibecast-vistawave' in ref['value']:
        print(hex(ref['address']),hex(ref['function_start']),ref['value'])
