package com.vibecast.recovery;

import org.json.JSONArray;
import org.json.JSONObject;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/** Searches values in the recovered application's JSON database records. */
public final class SearchText {
    public static final class Text {
        public final List<String> values = new ArrayList<String>();
        public final List<String> media = new ArrayList<String>();
        public boolean incomplete;
        private int characters;
        private String preferredTitle;
        private int titleDepth = Integer.MAX_VALUE;
        public String title() {
            if (preferredTitle != null) return preferredTitle.length() > 100 ? preferredTitle.substring(0, 100) + "…" : preferredTitle;
            for (String value : values) {
                if (value.length() > 1 && !value.matches("[0-9.\\-]+") && !value.startsWith("http") && !value.startsWith("/"))
                    return value.length() > 100 ? value.substring(0, 100) + "…" : value;
            }
            return "Saved record";
        }
        public String description() {
            StringBuilder out = new StringBuilder();
            for (String value : values) {
                if (out.length() > 0) out.append('\n');
                out.append(value);
            }
            return out.toString();
        }
        public boolean matches(String query) {
            String haystack = normalize(description());
            for (String word : normalize(query).trim().split("\\s+"))
                if (!haystack.contains(word)) return false;
            return true;
        }
    }

    public static String normalize(String value) {
        return Normalizer.normalize(value, Normalizer.Form.NFKD)
            .replaceAll("\\p{M}+", "").replace("ـ", "")
            .toLowerCase(Locale.ROOT);
    }

    public static Text parse(String value) throws Exception {
        Text result = new Text();
        String trimmed = value.trim();
        if (trimmed.startsWith("{")) collect(new JSONObject(trimmed), result, 0);
        else if (trimmed.startsWith("[")) collect(new JSONArray(trimmed), result, 0);
        else throw new IllegalArgumentException("Record is not JSON");
        return result;
    }

    private static void collect(Object value, Text result, int depth) throws Exception {
        if (depth > 16 || result.characters > 65536 || result.values.size() > 512) {
            result.incomplete = true;
            return;
        }
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject)value;
            if (depth < result.titleDepth) {
                for (String key : new String[]{"title", "name", "displayName", "display_name", "nickname", "username", "file_name"}) {
                    Object candidate = object.opt(key);
                    if (candidate instanceof String && !((String)candidate).trim().isEmpty()) {
                        result.preferredTitle = ((String)candidate).trim();
                        result.titleDepth = depth;
                        break;
                    }
                }
            }
            Iterator<String> keys = object.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String name = key.toLowerCase(Locale.ROOT);
                // Avoid displaying authentication material if a record contains it.
                if (name.contains("password") || name.contains("token") || name.contains("secret") || name.contains("authorization") || name.equals("cookie") || name.equals("api_key")) continue;
                collect(object.opt(key), result, depth + 1);
            }
        } else if (value instanceof JSONArray) {
            JSONArray array = (JSONArray)value;
            for (int i = 0; i < array.length(); i++) collect(array.opt(i), result, depth + 1);
        } else if (value instanceof String) {
            String text = ((String)value).trim();
            if (text.isEmpty()) return;
            if ((text.startsWith("{") || text.startsWith("[")) && text.length() < 65536) {
                try {
                    collect(text.startsWith("{") ? new JSONObject(text) : new JSONArray(text), result, depth + 1);
                    return;
                } catch (Exception ignored) { /* A normal title can contain braces. */ }
            }
            if (text.length() > 8192) { result.incomplete = true; return; }
            if (!result.values.contains(text)) {
                result.values.add(text);
                result.characters += text.length();
                String path = text.toLowerCase(Locale.ROOT).split("[?#]", 2)[0];
                if (path.matches(".*\\.(mp4|m4v|m3u8|webm|mkv|mov|3gp)$")) result.media.add(text);
            }
        }
    }
}
