import com.vibecast.recovery.SearchText;

public class SearchTextTest {
    private static int passed;
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
        passed++;
    }
    public static void main(String[] args) throws Exception {
        SearchText.Text account = SearchText.parse("{\"name\":\"Café Cinema\",\"channels\":[{\"title\":\"أفلام عَرَبِيَّة\",\"videos\":[{\"title\":\"Road Trip\",\"url\":\"https://example.test/video.mp4?expires=123\"}]}]}");
        check(account.matches("CAFE"), "case and accent insensitive account search");
        check(account.matches("عربية"), "Arabic diacritics");
        check(account.matches("Trip Road"), "all words, any order");
        check(account.matches("Cinema Road"), "nested channel/video matching");
        check(!account.matches("Cinema Missing"), "every query word is required");
        check(!account.matches("channels"), "JSON property names are not content");
        check(account.matches(""), "empty query shows saved content");
        check(account.title().equals("Café Cinema"), "meaningful title");
        check(account.media.size() == 1 && account.media.get(0).contains("?expires=123"), "media URL retains query parameters");
        SearchText.Text nested = SearchText.parse("{\"content\":\"{\\\"title\\\":\\\"Inner Video\\\"}\"}");
        check(nested.matches("inner video"), "nested JSON stored as a string");
        SearchText.Text secret = SearchText.parse("{\"title\":\"Documentary\",\"access_token\":\"hidden-value\",\"password\":\"hidden-password\"}");
        check(!secret.matches("hidden"), "authentication fields excluded");
        boolean rejected = false;
        try { SearchText.parse("not a JSON record"); } catch (Exception expected) { rejected = true; }
        check(rejected, "unreadable records are explicit");
        String huge = new String(new char[9000]).replace('\0', 'x');
        check(SearchText.parse("{\"large\":\"" + huge + "\"}").incomplete, "oversized field coverage reported");
        check(SearchText.parse("[{\"name\":\"First\"},{\"name\":\"Second\"}]").matches("second"), "top-level arrays");
        System.out.println(passed + " search behavior checks passed");
    }
}
