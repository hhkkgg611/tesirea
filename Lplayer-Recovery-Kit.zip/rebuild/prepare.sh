#!/bin/bash
set -euo pipefail
RECOVERY_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$RECOVERY_ROOT"
test -s lplayer-1-9-6.xapk
printf '%s\n' '6c54ff51d74724d411f4cb6d245d06f7fa38902f70bce68560dedb9f7e01d365  lplayer-1-9-6.xapk' | sha256sum -c -
mkdir -p tools original
fetch() {
  local destination="$1" url="$2" digest="$3"
  if [ ! -s "$destination" ]; then curl --fail --location --show-error "$url" --output "$destination"; fi
  printf '%s  %s\n' "$digest" "$destination" | sha256sum -c -
}
fetch tools/apktool.jar https://github.com/iBotPeaches/Apktool/releases/download/v2.11.1/apktool_2.11.1.jar 56d59c524fc764263ba8d345754d8daf55b1887818b15cd3b594f555d249e2db
fetch tools/APKEditor.jar https://github.com/REAndroid/APKEditor/releases/download/V1.4.9/APKEditor-1.4.9.jar a9cd40df818845456be6d696de6110c89edf4b0a0580cb83438ed6b25a366e67
fetch tools/uber-apk-signer.jar https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar e1299fd6fcf4da527dd53735b56127e8ea922a321128123b9c32d619bba1d835
fetch tools/json.jar https://repo.maven.apache.org/maven2/org/json/json/20250517/json-20250517.jar 3ea61b2a06e31edf1c91134fe9106b0ebb16628be169f3db75bc7a2b06b45796
fetch tools/android-platform.zip https://dl.google.com/android/repository/platform-36_r02.zip 37607369a28c5b640b3a7998868d45898ebcb777565a0e85f9acf36f29631d2e
fetch tools/android-build-tools.zip https://dl.google.com/android/repository/build-tools_r36_linux.zip 5d9ac77fb6ff43d9da518a337b4fcf8f9097113df531d99ccefe80ef7ce8250b
if [ ! -f tools/android-sdk/android-36/android.jar ]; then unzip -q tools/android-platform.zip -d tools/android-sdk; fi
if [ ! -f tools/android-sdk/android-16/d8 ]; then unzip -q tools/android-build-tools.zip -d tools/android-sdk; fi
python3 - <<'PY'
from pathlib import Path
import zipfile
with zipfile.ZipFile('lplayer-1-9-6.xapk') as archive:
    bad = archive.testzip()
    if bad: raise RuntimeError('Corrupt archive entry: ' + bad)
    for name in archive.namelist():
        if name.endswith('.apk') and Path(name).name == name and not Path('original', name).exists():
            archive.extract(name, 'original')
PY
if [ ! -f merged-original.apk ]; then java -jar tools/APKEditor.jar m -i lplayer-1-9-6.xapk -o merged-original.apk; fi
if [ ! -f decoded/apktool.yml ]; then java -jar tools/apktool.jar d -p tools/apktool-framework -o decoded original/com.vibecast.vistata.apk; fi
if [ ! -f merged/apktool.yml ]; then java -jar tools/apktool.jar d -s -p tools/apktool-framework -o merged merged-original.apk; fi
